
import one from '../assets/images/img1.jpg';
import two from '../assets/images/img2.jpg';
import three from '../assets/images/img3.jpg';
import four from '../assets/images/img4.jpg';
import five from '../assets/images/img5.jpg';
import six from '../assets/images/img6.jpg';
import seven from '../assets/images/img7.jpg';
import eight from '../assets/images/img8.jpg';
import nine from '../assets/images/img9.jpg';


//Gallery Component
function Gallery() {
  return (
    <section class="gallery-section container" id="gallery">
      <div class="section-heading">
        <div>
          <span class="eyebrow">THE COLLECTION</span>
          <h2>Moments worth framing</h2>
        </div>
        <span class="gallery-count">06 photographs</span>
      </div>

      <div class="gallery-grid">

       
        <article class="image-card">
          <div class="image-wrapper">
            <img src={one} alt="Coffee in a cozy cafe" loading="lazy"></img>
            <span class="category">Everyday Life</span>
          </div>
          <div class="card-content">
            <h3>Slow Mornings</h3>
            <p>A warm cup of coffee and a moment to yourself.</p>
          </div>
        </article>

       
        <article class="image-card">
          <div class="image-wrapper">
            <img src={two} alt="A Fairytale Castle in the Alps" loading="lazy"></img>
            <span class="category">Nature</span>
          </div>
          <div class="card-content">
            <h3>Timeless Beauty</h3>
            <p>Hidden among towering mountains and peaceful forests, where every view tells a story of timeless beauty..</p>
          </div>
        </article>

        <article class="image-card">
          <div class="image-wrapper">
            <img src={three} alt="Peaceful green mountain landscape" loading="lazy"></img>
            <span class="category">Nature</span>
          </div>
          <div class="card-content">
            <h3>Into the Wild</h3>
            <p>Finding peace where the mountains meet the sky.</p>
          </div>
        </article>

      
        <article class="image-card">
          <div class="image-wrapper">
            <img src={four} alt="Notebook and creative workspace" loading="lazy"></img>
            <span class="category">Creativity</span>
          </div>
          <div class="card-content">
            <h3>Pages of Possibility</h3>
            <p>Every beautiful idea begins with a little curiosity.</p>
          </div>
        </article>

       
        <article class="image-card">
          <div class="image-wrapper">
            <img src={five} alt="Beautiful evening sky" loading="lazy"></img>
            <span class="category">Sky & Light</span>
          </div>
          <div class="card-content">
            <h3>After the Sunsets</h3>
            <p>The sky reminds us that endings can be beautiful.</p>
          </div>
        </article>

      
        <article class="image-card">
          <div class="image-wrapper">
            <img src={six} alt="Sunlight passing through a green forest" loading="lazy"></img>
            <span class="category">Nature</span>
          </div>
          <div class="card-content">
            <h3>Golden Rays – Nature's Magical Morning</h3>
            <p>Where sunlight whispers through the trees, and every ray brings a little magic.</p>
          </div>
        </article>

        
        <article class="image-card">
          <div class="image-wrapper">
            <img src={seven} alt="Tropical beach with turquoise water" loading="lazy"></img>
            <span class="category">Travel</span>
          </div>
          <div class="card-content">
            <h3>Ocean State of Mind</h3>
            <p>Salt in the air and endless possibilities ahead.</p>
          </div>
        </article>

      
        <article class="image-card">
          <div class="image-wrapper">
            <img src={eight} alt="Lost in the woods, found in the moment." loading="lazy"></img>
            <span class="category">Travel</span>
          </div>
          <div class="card-content">
            <h3>Whispers of the Mist</h3>
            <p>The rain-kissed pathway reflects the peaceful beauty of nature.</p>
          </div>
        </article>

        <article class="image-card">
          <div class="image-wrapper">
            <img src={nine} alt="Timeless Elegance - The Crown of Love" loading="lazy"></img>
            <span class="category">Architecture</span>
          </div>
          <div class="card-content">
            <h3>Timeless Elegance</h3>
            <p>A timeless beauty that transcends trends and seasons.</p>
          </div>
        </article>

      </div>
    </section>
  
  );
}

export default Gallery;