//Footer Component
function Footer() {
  return ( 
    <footer class="site-footer">
    <div class="container footer-content">
      <span class="logo"> WonderFrames</span>
      <p>Made with curiosity, creativity & a little magic.</p>
      <span>© 2026 WonderFrames</span>
    </div>
  </footer>
  );
}

export default Footer;