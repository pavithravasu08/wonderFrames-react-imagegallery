//Hero Component  
function Hero() {
  return (
    <section class="hero container">
      <span class="eyebrow">A COLLECTION OF EVERYDAY MAGIC</span>
      <h1>Life is full of <em>little wonders.</em></h1>
      <p>
        A curated gallery of beautiful places, quiet moments
        and everyday stories worth remembering.
      </p>
      <a href="#gallery" class="explore-btn">Explore the collection ↓</a>
    </section>
  );
}

export default Hero;